# Task35：已确认非法工具参数的框架有界恢复

用户最新要求尽快收尾。本任务只修复已确认的故障，不再启动新的 Skill 诊断或拓展功能。

## 已确认边界

- Task34已冻结并独立批准；后端身份 `7acf24fd0ba74024a44fff29ecb66233280458f197a6e11295a88ff5a5086f01`。
- `deepseek-wire-v34a` 原TTY88539已读取正式退出1，两个新case为1失败／1通过。只用闭合safe报告和新增wire metadata，不读raw。
- 失败确为 `invalid_agent_tool_calls`：完整HTTP200／SSE／正常终止后，wire重建和SDK参数均为相同非法JSON，args_equal=true，comma_delimiter；不是SDK把合法对象改坏。该非法响应在图执行工具之前被拒绝，usage已按供应商事实结算。
- 原 `ModelRetryMiddleware(max_retries=2, initial_delay=0, on_failure='error')` 仅处理无效工具名称选择。复用这一官方机制，不新增循环、不修补JSON、不增加重试次数。

## 最小允许改动

生产仅 `backend/src/short_drama/agent/runtime/agent.py`：为既有 retry_on 提供明确谓词，保留原 invalid_tool_selection 的精确判断及 executor 分类；额外只允许已实际完成请求、accepted_unknown=false、code=invalid_agent_tool_calls 的 AgentGatewayError。不能仅因 accepted_unknown=false重试所有错误；raw replay的requests=0不触发重新生成，取消、截断、预算、网络／认证／未知发送均不新增重试。

测试优先复用 `backend/tests/unit/standard/agent/test_agent_context_capacity.py` 与 `test_assistant_model_protocols.py`，最多选两个；若已有真实graph用例更适合，可用 `test_framework_runtime.py` 替换其中一个，说明选择即可。禁止改自然live断言、提示、预算、锁文件、SDK、正式gateway解析或存储／工具结算。维护文档由父同步。

## 必要验证与交接

1. 保存最小before字节，先有效RED。用实际生产assistant_middleware取出的官方ModelRetry和真实create_agent／受保护SDK模拟响应，证明首次非法参数本来终止、修复后重新生成合法调用并只执行合法工具一次，原坏参数不被修补或执行。保留真实用量／错误回执及每次请求独立身份。
2. 确认连续非法输出最多三次调用后原错退出；无效名称原行为保持；unknown、stop／cancel、预算／其他code及requests=0反向不重试。沿真实官方机制测行为，不能只assert自写谓词。
3. 只跑新增定点和受影响现有文件，不重复已通过无影响大套件；源码／测试Ruff check与format --check，changed dry-run、docs／quality／diff必要门禁。禁用dotenv／外部tracking，后端cwd为backend。
4. 不调真实模型、媒体、DB或Docker，不读凭据，不提交、不改index/HEAD、不派子代理。临时报告、before/after与闭合命令仅SDD/task-35-*，不用昂贵大范围快照框架；所有旧失败与unknown保留。
5. 实现、必要回归、最小delta和报告就绪后立即停止写，交父fresh限定审查。用户要求尽快交付，禁止新增探索性测试矩阵／通用重试框架／技能修复。

新版真实验证由父单次安排；完整45项和三次长任务未全部通过的事实必须保留，不能用本任务本地通过追认。应用库迁移、用户服务切换、完整Celery部署不在本任务内。
