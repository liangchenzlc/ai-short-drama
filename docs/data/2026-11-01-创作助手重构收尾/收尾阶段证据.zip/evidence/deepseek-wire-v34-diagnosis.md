# deepseek-wire-v34a 工具 JSON 边界诊断

2026-11-01。仅离线读取本批安全报告、observer 固定元数据、新 wire observer 源码与 usage、launch/exit/log 及 Task 34 冻结证明；未调用模型、网络、DB 或 Docker，未读取密钥、`.env`、原请求响应、工具参数正文，未修改生产、测试或 driver。

本次 `interrupt_registered-1` 的失败可定位到 **接收到的完整工具参数已是非法 JSON**：wire 与 SDK aggregate 参数完全相同，均为同一 JSON 语法错误。安全元数据可以无歧义关联到该失败 Run 的 `assistant` receipt。没有证据支持本例在 SDK aggregate 转换时改变参数；更上游的生成过程与服务端内部原因仍为 unknown。

## 本批身份与结果

- 新的独立诊断，不是 v33 同输入复验。Task 34 已独立批准；批准记录与实际 launch 的 SHA 相符。
- 冻结生产 identity：`7acf24fd0ba74024a44fff29ecb66233280458f197a6e11295a88ff5a5086f01`。
- live 测试 SHA：`bd6ade134fbda1377983ed3b5e32734ea1d7d30e3fbb1d2f2d4e7da0385e5ebe`；wire observer 实际 SHA 与 launch driver manifest 相符。
- `exit.json`：PID 10632，`exit_code=1`、`process_closed=true`，结束于 `2026-10-31T17:06:37.156626+00:00`。日志：**1 failed、1 passed、43 deselected，158.45 秒**。
- 两份安全报告均 `report_collection.status=complete`。文本模型为 `deepseek-flash`，媒体供应商为 `mock_only`。

| 本文别名 | 新 case | Run | receipts | worker PID 顺序 |
| --- | --- | --- | ---: | --- |
| I | interrupt_registered-1 | failed，`invalid_agent_tool_calls` | 6：5 succeeded、1 failed | 13540 → 33844 → 504 |
| A | answer_committed-1 | succeeded | 8：8 succeeded | 35208 → 11192 → 37548 |

I 与 A 各有一个 scope。下文 `I.R6` 是 I 安全报告第 6 条 receipt 的本地别名，`I.S1` 是其唯一 scope；不输出真实工具 call ID 或 ID 指纹。

## 失败边界及关联

同一 O504 文件、同一 PID 504 的事件序列如下。wire observer 使用独立 ContextVar 包住单次 `_agenerate` 生命周期；该序列中没有夹入另一次请求。wire 事件自身没有 Run/receipt/scope 字段，因此关联依赖以下连续事件，以及 gateway、turn 与安全报告中 ID 的内存等值比较，未单凭时间接近推断。

| O504 行 | 元数据事实 |
| ---: | --- |
| 36–39 | `assistant` 请求开始、admission 返回、headers、first_byte；admission 后的 model call 对应 I.R6 |
| 40–44 | terminal → stream_close_started → http_body_complete → request_returned → stream_close_succeeded；terminal_seen=true、scan_failed=false、scan_truncated=false；最终 stream_ended=true、feed_done=true、feed_cancelled=false |
| 45 | `sdk_invalid_tool_calls`：source=assistant，finish_reason=tool_calls，valid=0、invalid=1，aggregate_chunk_count=1 |
| 46 | `wire_sdk_tool_arguments`：source=assistant、status=complete、wire_reconstruction_complete=true、reason=null |
| 47 | gateway：source=assistant、outcome=raised、code=invalid_agent_tool_calls；requests=1、accepted_unknown=false、replay_requested=false、admission_returned=true；model call 对应 I.R6 |
| 53 | turn：I.R6、Run I、scope I.S1，status=failed、HTTP 200、settled=true、actual_wire_stream=true；error.code=invalid_agent_tool_calls，accepted_unknown=false、not_accepted=false、requests=1 |
| 55 | worker_readback_complete 对应 Run I；O7908 第 4 行清理前 Run 状态也为 failed |

第 47 行异常类型为 `short_drama.agent.gateway.contracts.AgentGatewayError`，安全栈帧位于 `short_drama.agent.gateway.langchain._agenerate` 第 513/406 行；未观测到 TimeoutError 或 asyncio timeout exit。实际观测阶段为 **assistant 响应完整接收后，gateway `_agenerate` 抛出工具调用错误**。持久化 Run/turn 没有单独的 `error.phase` 字段，其字段值为 **unknown**；`interrupt_registered` 是本 case 注入故障的边界，不能替代最终失败阶段。

| 第 46 行参数事实 | wire | SDK aggregate |
| --- | --- | --- |
| 类型、字符数、UTF-8 字节数 | str、967、2148 | str、967、2148 |
| JSON | invalid；top_type=null | invalid；top_type=null |
| 固定错误分类 | JSONDecodeError / comma_delimiter | JSONDecodeError / comma_delimiter |
| 错误位置 | position=963、line=1、column=964 | position=963、line=1、column=964 |

该 call `args_equal=true`、fragment_count=598；wire/sdk call_count 均为 1，SDK valid/invalid 为 0/1。两侧 index、ID 存在布尔均为 true；index_conflict、id_conflict 均为 false。旧 invalid observer 同时记录 distinct_index_count=1、distinct_id_count=1、duplicate_index_count=0、duplicate_id_count=0、index_multiple_id_count=0，且未省略 aggregate/invalid 项。这里只使用存在与计数信息，没有输出 index 值或原 ID。

`status=complete` 的实现要求 HTTP 200、完整 SSE、可接受 finish、DONE、参数片段与唯一映射。结合 wire 非法和 `args_equal=true`，本例能确认接收边界已有非法参数；不能进一步判断供应商内部为何产生此参数，也不能指名某个 SDK merge 函数。

## 本批覆盖与去重用量

7 个 observer JSONL 共 209 条事件：14 次 gateway invocation，14 次 wire observation，均 complete，unknown=0。14 个工具 call 的参数均相等；wire/SDK 为 13 valid、1 invalid；无 index/ID 冲突。一个完整 observation 没有工具 call，另一个含两个 call。6 个 worker completion 均 returncode=0、observer_write_failed=false；这不改变 pytest 的最终 exit 1。

20 条 turn_readback 只有 14 个唯一 model call，重复项来自跨 worker 回读。用量仅按两份完整安全报告的 receipt ID 与 model_call_id 去重，各为 14 个唯一值；不再叠加 Run 总量、gateway/observer 行数。14 条均 settled/input_settled/cached_settled=true，且 usage_reported/output_tokens_reported=true；失败的 I.R6 也已结算。各 case receipt 合计与其 Run 用量相符。

| case/source | receipts | input | output | cache（包含于 input） | admission 预留字段累计 |
| --- | ---: | ---: | ---: | ---: | ---: |
| I / assistant | 3 | 32931 | 1849 | 29312 | 24576 |
| I / tool_selection | 3 | 8082 | 265 | 7424 | 24576 |
| I 合计 | 6 | 41013 | 2114 | 36736 | 49152 |
| A / assistant | 4 | 46446 | 1821 | 39168 | 32768 |
| A / tool_selection | 4 | 10842 | 333 | 9984 | 32768 |
| A 合计 | 8 | 57288 | 2154 | 49152 | 65536 |
| 本批总计 | 14 | 98301 | 4268 | 85888 | 114688 |

本批 uncached input=12413；external_requests 合计 14。`114688` 是本批 14 条 receipt 的历史 admission 预留字段累计（每条 8192），不是剩余预留或额外消耗。**本批两个 Run 的 reserved_output_tokens 均为 0，合计剩余预留为 0。** 父任务提及的旧批次 14 条 unknown receipt 不在本批统计范围；本诊断未读旧报告，其剩余预留保持 unknown，不与本批 0 混写。不估价、不推算账单。

A 的安全事实为 cross_worker=true，duplicate_business_writes/duplicate_questions/duplicate_answers 均为 0；仅证明本次新 `answer_committed-1` case 通过，不追认旧失败。两份报告的 sandbox_cleanup 与 minio_namespace_cleaned 为 true；这是报告记录，本诊断未另连服务核验。

## 证据边界与最小下一步

已证实的根因层是完整响应中的工具参数 JSON 语法；失败 source/scope/receipt 关联明确。具体错误字段、正文、供应商生成原因与独立持久化 phase 均未读取或不可知。下一步只需由父任务据此处理 `invalid_agent_tool_calls` 的既有模型错误边界，并执行该分支必要回归。本诊断不再扩大采集，不运行新 probe。

本次只新增本报告，未运行测试、文档门禁或质量门禁；工作属于 `.runtime` 诊断记录，未改变代码或维护文档。原 live 结果来自上述已闭合产物。

## 固定来源清单

下表路径均相对于 SDD 目录 `C:/Users/snow/.codex/worktrees/assistant-runtime/ai-short-drama/.runtime/sdd/2026-10-29-创作助手运行时与工具扩展重构实施`；SHA 为原文件实际字节的 SHA-256。

| 来源 | 文件 | bytes | SHA-256 |
| --- | --- | ---: | --- |
| launch | deepseek-wire-v34a-launch.json | 163359 | fe8158a847d3016d975e3fb5fe06b4560af56a65fa5cfe45c5c1015e694287fe |
| exit | deepseek-wire-v34a-exit.json | 173 | 98784b42c9f0a1119053479dd396dedc51261647913b88fb8d129fbd691028b4 |
| log | deepseek-wire-v34a.log | 2647 | a0a295f1541334a0f06533b2d3a17eb4aad9a855b29f6bb2bd76554a6e1f5337 |
| R-I | deepseek-wire-v34a-reports/test_live_crash_windows_keep_one_business_or_answer_identity-interrupt_registered-1-abaef107e5.json | 17042 | c97845c0552b35ac5d347073aa9fcacfd34d8b3451e03ac77cacf04dbe88776e |
| R-A | deepseek-wire-v34a-reports/test_live_crash_windows_keep_one_business_or_answer_identity-answer_committed-1-57db442e28.json | 23687 | 032fc110800cf17b7cde9859ddca1591ce21d220923f023cb858bf59c3f85035 |
| O11192 | deepseek-wire-v34a-observer/observation-11192-73b7a05dd9524513b5a775f995c86446.jsonl | 262 | 7c64bc16e3540f5a5252eb9eccfa4bfafc418e72224725158702e88a2668c28e |
| O13540 | deepseek-wire-v34a-observer/observation-13540-36bf608df0064d318634a5f45da9ccd8.jsonl | 14012 | 1b7abc5946d643707ed78c04fe732581d7df2bcb31204927eec967de8d49cc37 |
| O33844 | deepseek-wire-v34a-observer/observation-33844-f710facc3a254514ba009832d43b1e8e.jsonl | 1701 | 2614934950621abd6ff9935b0be589203dbf6747376a4ae1ddd61ea4404944f2 |
| O35208 | deepseek-wire-v34a-observer/observation-35208-a768cb8ea10249f99319f3eb0c618e5e.jsonl | 14523 | 86c7302898e78b627499b7314315a5d71ad6fea9be63661c091482fb8de90b8c |
| O37548 | deepseek-wire-v34a-observer/observation-37548-69c0fe8a2c1f45c998897c45173c3353.jsonl | 40840 | ee098534a71178432b4fbc2016e22231da0e8773bac48beabea7becfa80032f8 |
| O504 | deepseek-wire-v34a-observer/observation-504-f48a457c2dfe4e46a00c316c70417f68.jsonl | 29800 | f7f3d751dd57b49cb2db0f395608dac7795c069d0cdc78ef46f54dbf6a42e990 |
| O7908 | deepseek-wire-v34a-observer/observation-7908-pytest.jsonl | 3610 | 01f99015547865eac5b9d9ee763bc1327ef548576ff7080f2d80bca0f102599b |
| observer | deepseek_wire_argument_observer.py | 15025 | 33c72b9e95fcc03220a4e515054c219ba695b16a3b68df231adc9fbbb18c6659 |
| usage | deepseek_wire_argument_observer-usage.md | 3654 | f1ea032e9b7fa895221d0088917c7dbc1809024c3ff07f4f823b9d448de26748 |
| approval | task-34-parent-approved-and-wire-launch.json | 865 | 21e734dba2e6b133f2756f5893bb837e95b06883814254726c7fe606ecae066b |
| freeze | task-34-parent-freeze.json | 1558 | 4bfef09eb177521a4db4b50eb5eaa758649111efbd7df295fab8c7c3883dfdbc |
| proof | task-34-scope-proof.json | 4949 | 1fdc92fc467ec8613199cb71ea41f4ee96cd68ff0b497d59f8e7482b6bceee07 |
