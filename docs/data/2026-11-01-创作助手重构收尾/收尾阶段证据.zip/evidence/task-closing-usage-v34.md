# 收尾用量增量：v34

已闭合 deepseek-wire-v34a 两份报告：1 通过、1 失败。新增 2 Run / 14 receipt / 14 model_call_id，与 after33 的三类身份均无重复。

| 范围 | Run | receipt | input | output | cached | reserved output |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| after33 | 386 | 5,981 | 43,694,460 | 1,786,543 | 13,195,167 | 114,688 |
| v34 增量 | 2 | 14 | 98,301 | 4,268 | 85,888 | 0 |
| 合并 | 388 | 5,995 | 43,792,761 | 1,790,811 | 13,281,055 | 114,688 |

合并 input 缺失仍为 2 Run，其余三项无缺失；原 14 个未决身份及 114,688 Run 预留原样保留，新批无新增未决或预留。旧 probe、summary sanity、诊断及其 unknown、GET discovery 均独立保留，实际账单 unknown。

本次只做已闭合报告的最小数据追加，没有重跑测试、拼接跨版 45 成功结论或读取活动 close-v35a case。旧文件不覆盖。来源 SHA 与字节数、完整新增身份和安全数字用量见 [JSON](./task-closing-usage-v34.json)。
