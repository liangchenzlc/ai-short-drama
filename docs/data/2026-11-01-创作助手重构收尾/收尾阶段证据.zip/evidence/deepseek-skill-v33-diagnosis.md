# v33 DeepSeek Skill 五例只读诊断

本报告只使用已关闭的 safe 报告、固定 observer metadata 和源码；未访问数据库、模型、原请求、原响应或 raw/wire，未修改生产代码、测试与 driver。所有涉及合成标记的检查均只保留布尔、字段路径或计数，不保存标记值与消息正文。

## 证据身份

- `v33-before34-source-proof.json` 确认原 supervisor 均已关闭，`source_and_actual_drivers_unchanged=true`；v33 backend identity 为 `2d9c27e4e956f3c0ce9e6204cfc1fa7c124d92d831f5e579d55dc9c6b5ca6386`。
- `test_agent_runtime_live.py` SHA256 为 `bd6ade134fbda1377983ed3b5e32734ea1d7d30e3fbb1d2f2d4e7da0385e5ebe`，本次复核一致。下述行号均指该版本。
- 五份 `deepseek-rest-b-v33a-reports/` 报告均为 `report_collection.status=complete`，且 `passed=false / test_body_passed=false`；报告采集完成不代表验收通过。
- Gateway 参考 `task-33-after-r2/backend/src/short_drama/agent/gateway/langchain.py` 不可变副本，SHA256 `4584fbf6f4764621e218fbf3a852bf86ac868a82118accfea7aacb3855881a23`。Task34 当前生产文件不作为 v33 身份。

## 五例分类

| 用例与 safe 报告尾缀 | 已确认失败 | 当前分类与边界 |
| --- | --- | --- |
| canonical reload[0]，`-0-5ba6e91d3b.json` | Run succeeded；L1350 `canonical_context_released_source_returned` | 清理契约问题候选；规范化后残留字段未定位，不能认定 reasoning 或原正文恢复。 |
| withdrawal selection[1]，`-selection-1-5900359936.json` | Run succeeded；L1567 撤回标记仍在新 Turn 请求 | 撤回清理问题候选；现有观察缺少字段和来源分类，产品缺口与历史显示/证据断言边界仍需区分。 |
| withdrawal forget[0]，`-forget-0-532aea30ce.json` | Run failed；L1564 `assert_success` | 已确认摘要后的 middleware 预算拒绝；未进入 L1567，不能判定遗忘标记清除是否成功。 |
| parent_child_skill[0]，`-0-e30ca9726a.json` | Run succeeded；L1601 activation 数 3≠2 | 精确数量 oracle 强于隔离契约；合法 release/reload 与错误 scope 加载尚未区分。后续正文隔离断言未执行。 |
| canonical reload[1]，`-1-f6fad6d742.json` | L1443 首个目标结果的 `match_excerpt` 不含指定尾词；Run 后为 cancelled | 已有模型查询选择证据，加上“首个目标结果必对应尾词查询”的测试假设；无检索实现缺陷证据。 |

## release 与 selection：来源组已撤，剩余字段未知

canonical[0] 首次 release 后，observer 记录原 activation 失活、8 条 load/read/duplicate-load/release 的完整 AI/Tool 消息被撤；这些 Tool 来源标签齐全。未见 inactive 正文由 `_restore_skill_bodies` 恢复。随后新 activation 的合法重载复用了 canonical body operation，不能将之后的重载算作失活窗口泄漏。

在该失活窗口的 16 次 assistant 请求中，framework 的 `message.content` 检查 body/resource 均为 false；admission 递归聚合为 body=false、resource=true。已投影的 resource 命中仅位于原 ask 的 `ask_projection.question`，属于 L1121–1253 helper 会遮掉的已消费表单显示字段。这个聚合阳性不能解释 L1350 规范化后的失败，也不能从 content=false 反推出 reasoning=true。

observer 的 framework 标记仅检查 content；admission 检查整个消息字典，未分别统计 reasoning、表单显示、已答证据、summary、notes 和其他 args。safe model diagnostics 也没有原请求 reasoning。selection[1] 的 observer 只有 gateway/transport/turn metadata，无法进行同等定位。两案的剩余字段与传播链均为 **unknown**。

源码存在可复现的机制风险：`context/graph.py:349–376` 按来源/activation 标签删除完整调用组，不推导未标记的后续 AI 来源；`service/assistant/execution/tools.py:133–154` 保存主 AI graph message 时没有同等 Skill 来源接线。v33 DeepSeek 适配会把保留 AI 的 `additional_kwargs.reasoning_content` 带回请求。纯合成 AST 核验已证明：原 load 组撤除后，无 activation 标签的后续 AI reasoning 载体仍在；补上该标签则被撤。**这只证明机制，不证明原案残留在 reasoning**。普通 AI 内容、工具参数或其他未投影字段同样不能排除；现有 summary 来源接线也不足以证明 summary/notes 在原案中干净。

## forget[0]：摘要成功后总量仍超 110 tokens

safe Run error 为 `agent_context_budget_exhausted`，原 `context_budget` 完整字段如下：

```json
{
  "phase": "post_summary",
  "source": "assistant",
  "fixed_kind": "system_tools_and_pinned",
  "message_count": 8,
  "tool_call_count": 3,
  "tool_result_count": 3,
  "input_limit_tokens": 18432,
  "context_window_tokens": 32768,
  "estimated_input_tokens": 18542,
  "reserved_output_tokens": 8192,
  "complete_tool_group_count": 2,
  "fixed_estimated_input_tokens": 13152
}
```

`fixed_kind` 表示计量类别，不表示固定部分自身超限：固定 13152，动态余量 5280，总量超 110。原对象没有其他 reserved 字段。最后一个实际模型回执是成功摘要（receipt `374956946015215616`，call `074430ed52664d319ea4ad5134971eb7`）：input=2916、output=2220，observer returned/admitted 均为 true，未报告 reasoning 明细。

`runtime/middleware.py:345–371` 在摘要完成、合并 pinned 消息后再次估算并拒绝，未保证新摘要长度适配剩余空间。仅把记录值代入 L301/L333 默认公式，可得 keep=14472、trigger=16847（浮点乘法后 `int` 取整）；该次是否用了特殊 keep、真实 cutoff、尾组成本及新摘要替换成本没有完整 metadata，不能定因到其中一项。12 是 helper 调用计数，不能直接称为 12 次独立压缩。

因此本例属于 middleware 的摘要后预算问题；不同于 long[0] 的 main SDK pre-send guard，也没有摘要 8192 截断证据，不能直接归为 Task34 同因。

## reload[1] 与 parent_child：先验证轨迹，再判契约

reload[1] 的唯一 search operation 在内存比较得到：`query_is_requested_tail=false`、`query_contains_requested_tail=false`、`query_is_skill_name=true`。`skill/progressive.py:75–125` 根据实际 query 匹配候选，并在 description/exclusions 中围绕该 query 取 excerpt。因此按方法名找到目标而 excerpt 没有尾词符合实现。L1437–1443 从所有成功搜索取首个目标 item，没有约束这个 item 的 query；本次不修改断言。

parent_child 记录 load=3、release=2，覆盖两个目标 Skill、两个 scope、三个 activation。`skill/progressive.py:156–179` 仅对同 scope、同版本且 active 的加载复用 activation；L301–365 在失活后重载时新建 activation，可复用 canonical body operation。上述数量可由合法重载产生，但缺少逐 load 的 scope/skill/activation 映射，不能据此确认合法，也不能据此宣称跨 scope 泄漏。L1612–1613 的正文隔离检查尚未执行。

## 最小下一步

1. 在冻结版本用独立新 fixture 为 release/selection 加入标量观察：按 framework、DeepSeek typed restore、SDK 序列化三个阶段，分别报告标记是否处于 content、reasoning、ask 显示字段、已消费答案证据、summary、notes、其他工具 args；只输出布尔、消息类别、来源/activation 关联及 oracle 规范化前后结果，不输出正文、args 或标记值。不得由递归聚合推定具体字段。
2. 先做纯合成回归：调用真实来源撤回实现，覆盖带/不带来源标签的后续 AI、已答表单规范化与 typed restore/DeepSeek 字段序列化，定位丢失来源或残留的具体阶段。
3. forget 只补摘要前后 fixed/pinned/保留尾组/新 summary 的估算值、cutoff 和实际 keep 模式，使用同一冻结版本独立 fixture 重现 post_summary 超限；不改预算、不弱化断言。
4. parent_child 仅补每次 load 的 scope、skill、activation、此前 release 关联及是否重用，再分别判定 scope 隔离和合法重载。reload[1] 的后续观察仅需记录 query 是否等于指定尾词以及 oracle 选中的 operation 身份。

本次验证仅为关闭产物与源码只读核对、纯合成 AST 检查及报告数据一致性检查；未重新执行真实模型、数据库或供应商验收。
