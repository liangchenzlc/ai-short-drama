# Task35 r2：审查 I1 修复与冻结

2026-11-01。仅修复 `task-35-review.md` 的 I1，源码与正式测试已停止写入，交原审查者定向复审。r1 原件与审查复现文件均未覆盖；维护文档由父任务同步。

## 最小改动

- `backend/src/short_drama/agent/runtime/middleware.py`：将主 `await handler(...)` 放到 `model_compaction.get()` / `pending.extend(retained)` 前。失败尝试不会提交待持久化摘要，成功后才保留对应历史。统一差异仅 3 增 / 3 删，文件大小不变；没有新增回滚、缓存或重试机制。
- `backend/tests/unit/standard/agent/test_agent_summary_budget.py`：新增一个正式回归，使用生产 `assistant_middleware` 提取的官方 Retry、`bound_model_middleware` 排序、官方 `_chain_async_model_call_handlers`、真实 `SkillSummarizationMiddleware` / `BoundedSummary`。只有摘要模型返回合成文本，主 handler 首次抛精确 `invalid_agent_tool_calls`、第二次成功；不复制重试或摘要算法。
- 新回归同时断言 pending 与成功 command 的 retained 历史及成功主请求一致，正式消息 serializer 与官方 `add_messages` 恢复后仅含最终摘要。ContextVar 在测试结束恢复。

## 实际 RED → GREEN

生产修改前保存两个文件原始字节与 SHA 至 `task-35-r2-before/`、`task-35-r2-before.json`。新定点首次执行即获得有效 **RED：1 failed / 28 deselected，exit 1**，失败断言为 pending 4 条而成功 retained 2 条。

| 同一正式回归的事实 | RED | GREEN |
| --- | ---: | ---: |
| 主 handler 尝试 | 2 | 2 |
| 真实摘要 helper 调用 | 2 | 2 |
| 官方成功 commands | 1 | 1 |
| 待持久化 pending 消息 | 4 | 2 |
| live 摘要数 | 1 | 1 |
| replay 摘要数 | 2 | 1 |

原始 pytest 属性保存于 `task-35-r2-red.xml` / `task-35-r2-green.xml`，安全计数提取至 `task-35-r2-summary-evidence.json`；有效 RED 日志和退出事实完整保留。

修复后只跑受影响的整个摘要测试文件：**29 passed / 1 warning，exit 0**。其中 1 项为新回归、28 项为原摘要组；warning 为两次均出现的 Starlette 导入 AnyIO `BlockingPortal` 弃用提示，未更改依赖或屏蔽警告。r1 的 15 项未重跑。

## 门禁与执行边界

- `python -m ruff check src`、`python -m ruff check tests`、`python -m ruff format --check src`、`python -m ruff format --check tests`：均 exit 0；1155 个源码文件、408 个测试文件格式通过。
- `node scripts/test.mjs --changed --dry-run`：exit 0，现有整个工作区预览 269 项，未执行该大范围计划。
- `node scripts/check-docs.mjs`：exit 0，35 份维护文档、121 张表、48 路由模块。
- `node scripts/check-quality.mjs`：exit 0，1702 源文件、0 处已知结构问题；既有规模提示保留。
- `git diff --check`：exit 0；既有 LF/CRLF 提示保留。

上述验证进程均已正式退出；开始、结束与实际退出码见 `task-35-r2-*-exit.json`，原始输出见同前缀日志。

后端 cwd 为 `backend/`，执行前设置 `PYTHONPATH=src;.`、`PYTHON_DOTENV_DISABLED=1`、`PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`、`LANGSMITH_TRACING=false`、`LANGCHAIN_TRACING=false`、`LANGCHAIN_TRACING_V2=false`、`OTEL_SDK_DISABLED=true`，导入 pytest 前设 `Settings.model_config['env_file']=None`。RED 选择 `test_agent_summary_budget.py -k retry_commits_only`；GREEN 执行该文件全部用例，均使用 `-q --tb=short -p no:cacheprovider` 并保存独立 JUnit。

未使用网络/TCP、真实模型、DB、Docker或凭据，未提交或操作 index/HEAD，未派子代理。未修改长测、预算、提示词、锁文件、SDK、Gateway 或其他生产文件。

## 冻结身份与保留事实

| 本次文件 | after SHA-256 |
| --- | --- |
| `backend/src/short_drama/agent/runtime/middleware.py` | `da4964aeec3bd2e258e30234d3476b8374b34ff8242c52fb33b31b94f3467991` |
| `backend/tests/unit/standard/agent/test_agent_summary_budget.py` | `9eefbc71a1e306d165a0afa4b615c45d15071dc9eb4c713be2f84fb9b5b01579` |

`task-35-r2-after/` 保存相同两文件实际字节；`task-35-r2-after-manifest.json` 保存前后 SHA 与大小；`task-35-r2-delta.patch` 仅对 unified diff 作 LF 归一化；`task-35-r2-freeze.json` 汇总实际门禁、RED/GREEN 计数与保护文件身份。没有新增全仓快照流程。

r1 `agent.py` 仍为 `889d49b519cf777158b6f5ab45df9abd7d92729c8d1188bd060f41b3183c3530`，协议测试仍为 `115c9a5f5c1f361417d206cb065b04f72872d92ac850fd77d8b6e472c8bd815a`。Task34 三个生产文件也逐字节符合其 after manifest。

本地通过只证明受控官方链及摘要恢复契约。旧 wire 仍为 1 failed / 1 passed；完整 45 项与连续三轮长任务尚未全部通过，不追认旧失败或 unknown。供应商、数据库持久化结算、迁移、用户服务切换与完整 Celery 部署均未由本次验证。父任务负责定向复审及其授权的单次短真实核验。
