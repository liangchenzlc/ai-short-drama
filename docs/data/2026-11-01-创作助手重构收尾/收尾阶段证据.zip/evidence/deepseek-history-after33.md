# DeepSeek 闭合历史用量：after33

v33 四批均已闭合：43 个实际执行 case，34 通过、9 失败；long [0] 失败后 [1]、[2] 未执行。保留全部原失败与未执行，不表示完整 45 项通过，也不宣称 Task12 验收通过。

| 范围 | Run | receipt | model_call_id | 已记录 input | 已记录 output | 已记录 cached | Run reserved output | input 缺失 Run |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| before33 | 329 | 5,245 | 5,245 | 38,500,118 | 1,520,732 | 9,738,667 | 106,496 | 2 |
| v33 增量 | 57 | 736 | 736 | 5,194,342 | 265,811 | 3,456,500 | 8,192 | 0 |
| after33 合并去重 | 386 | 5,981 | 5,981 | 43,694,460 | 1,786,543 | 13,195,167 | 114,688 | 2 |

只累加唯一 Run 的用量；receipt/provider usage 和独立 probe 不重复加入 token。v33 的四项 Run 字段无缺失；合并后 input 仍缺失 2 Run，其余三字段无缺失。缺失字段不补零。

v33 新增 1 个 status=unknown、settled=false 的 receipt，accepted_unknown/not_accepted 未记录。receipt 374954297022828544 / model_call_id f82722fe7f6244ad85a46befd037d3b8；唯一报告 Run 374954016474222592 保留 8,192 reserved output。原 13 个未决身份与 106,496 预留均保留；合并为 14 个未决身份、114,688 Run 预留，未释放或重放。历史 long1 无报告覆盖缺口继续未知。

| v33 批次 | 通过 | 失败 | 未执行 | Run | receipt |
| --- | ---: | ---: | ---: | ---: | ---: |
| deepseek-protocol-v33a | 2 | 0 | 0 | 2 | 8 |
| deepseek-long-v33a | 0 | 1 | 2 | 1 | 24 |
| deepseek-rest-a-v33a | 21 | 1 | 0 | 32 | 327 |
| deepseek-rest-b-v33a | 11 | 7 | 0 | 22 | 377 |

四个 launch 的后端 manifest（1,161 项）与 driver manifest 一致，后端 identity 重算为 2d9c27e4e956f3c0ce9e6204cfc1fa7c124d92d831f5e579d55dc9c6b5ca6386，long 测试 SHA 一致。父 v33-before34-source-proof.json 记录原 supervisor 均闭合且当时源码/driver 未变。当前 Task34 源码未读取或比较，此处只归属历史 v33。

独立请求继续排除在正式 case/Run 总量外：

- 新 summary sanity 已闭合：1 个成功 POST，input 908 / output 46 / cached 0，独立 model_call_id 2ec286e00c564f2ba59a25705bfec195。
- 原 DeepSeek probe 7 个成功 POST 与 1 个 structured 拒绝照旧单列；首次 thinking probe 的结果、用量及请求数仍未知。
- 旧 provider 诊断的 3 个已知请求及另 2 个结果/用量未知请求原样保留。
- 模型 discovery 为 GET，单列；实际供应商账单仍 unknown。

[v33 安全闭合投影](./deepseek-closed-version33.json) 保存全部 43 case、安全 ID/status/数字用量和来源 hash/bytes；[合并机器数据](./deepseek-history-after33.json) 固定 before33 与 v33 身份引用并提供全量去重及来源校验。原 before33、closed-version32 未覆写；未执行 deepseek-v33-collect.py，未调用模型、数据库或 Docker，未读取凭据/.env/raw wire 或 Task34 活动测试。

产物供父级复核；本次只核历史数据，不重跑验收。
