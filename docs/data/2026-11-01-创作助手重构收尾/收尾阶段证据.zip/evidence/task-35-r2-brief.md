# Task35 r2：只修复审查 I1

本文件是 task-35-brief.md 的最小范围补充。原 task-35-review.md 及复现、r1 快照和日志保持不变。用户要求尽快收尾，不扩展排查。

已确认 I1：官方重试前主模型失败，但 SkillSummarizationMiddleware 已先将 retained 写入 model_compaction，下一次成功后持久回执包含失败尝试的摘要，造成 live summary=1、replay summary=2。

明确允许增加的生产文件仅 backend/src/short_drama/agent/runtime/middleware.py：将 pending=model_compaction.get() 与 pending.extend(retained) 移到 await handler(...) 成功返回之后、返回 ExtendedModelResponse 之前。不要引入回滚、缓存或重试框架；r1 的 agent.py 和协议测试字节保持。

允许增加的正式测试仅 backend/tests/unit/standard/agent/test_agent_summary_budget.py：借鉴 task-35-review-repro.py，使用生产配置取得的官方 Retry、真实 bound middleware 顺序与官方 handler chain、真实摘要实现，首主调用非法 JSON 错误、次成功。先记录有效 RED，再 GREEN。断言 pending 仅等于成功 command 保留历史、恢复重放只含最终摘要；不复制运行时算法。

验证只跑新回归和受影响摘要组，已有 r1 15 项无代码变化不必再跑。运行必要 Ruff/format、changed dry-run、docs/quality/diff 门禁。报告写 task-35-report-r2.md，另存 r2 before/after/delta/freeze/闭合退出，不能覆盖 r1 原产物。提交给父定向复审后停止所有源码写入。

无真实模型、网络、DB、Docker、密钥、提交或子代理操作。不得修改正式长测、预算、提示词、锁文件、SDK 或其他生产文件。完整45项、连续三轮长测尚未通过，不能由此追认。
