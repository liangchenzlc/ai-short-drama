# Task34：DeepSeek 历史计量与框架用量兜底交付报告

日期：2026-11-01（Asia/Shanghai）。本报告对应 [task-34-brief.md](task-34-brief.md) 的限定修复。生产、正式测试和维护说明已冻结，等待独立审查；尚未进行新版真实供应商验收。

## 放行、范围与冻结

写入前先完成 [只读准备](task-34-prepare.md)，在父明确放行并提供 [v33 全部运行者闭合及源身份检查](v33-before34-source-proof.json) 后，保存了 [七路径 before 清单](task-34-before-manifest.json) 与 [原字节快照](task-34-before/)。开始门槛中的 `all_original_supervisors_closed`、`source_and_actual_drivers_unchanged`、`task34_writes_may_start` 均为 true。保留工作区既有改动，未提交、未修改 Git index/HEAD。

本任务只改 3 个生产文件、2 个测试文件、2 份维护说明：

| 路径 | 本次变化 |
| --- | --- |
| `backend/src/short_drama/agent/gateway/deepseek.py` | 从原 SDK 薄桥抽出 `with_reasoning_content` 纯函数；复制序列化消息 dict，按原消息顺序 strict zip 回填已存在的 AI 历史 reasoning，SDK 复用同一函数 |
| `backend/src/short_drama/agent/resources/graph.py` | 保存冻结 provider，仅 DeepSeek + `openai_chat.v1` 的引用计量投影复用该回填；继续走原 `references_only` 水合与 `request_template` |
| `backend/src/short_drama/agent/gateway/langchain.py` | 保护模型覆盖 `_get_ls_params`，调用 super 保留已有 LS 参数，仅补实际 SDK provider：DeepSeek chat→deepseek，Claude Messages→anthropic，其余 ChatOpenAI 路径→openai |
| `backend/tests/unit/standard/agent/test_assistant_model_protocols.py` | 新增 5 参数真实 SDK 请求/投影对照，以及 5 参数官方 reported-token fallback 对照 |
| `backend/tests/unit/standard/agent/test_agent_summary_budget.py` | 新增两轮累计 reasoning、真实摘要、原 SDK 准入守卫与 typed 恢复回归 |
| `docs/instruction/Agent模式部署与排障.md` | 同步共用投影、实际 SDK 身份及计量含义 |
| `docs/instruction/AI创作助手Harness运行机制.md` | 同步上述接线及预算、跟踪边界 |

没有修改 `runtime/middleware.py`，没有新增摘要算法、重试、窗口、预留调整或 reasoning 丢弃。Skill、工具 JSON、提示、stop/interrupt/subagent 语义不在本任务修改范围。README、系统架构及总计划由父按分工同步。

冻结命令 [记录](task-34-freeze.command.json) / [输出](task-34-freeze.log) 为 exit0、closed。它核对了七路径 before 哈希、保存 [after 快照](task-34-after/)、生成 [after 清单](task-34-after-manifest.json) 与 [相对本任务 before 的完整上下文差异](task-34-delta.patch)，并验证 [scope proof](task-34-scope-proof.json) 中全部 22 份先前命令的实际闭合与预期退出码。

| 产物 | SHA256 |
| --- | --- |
| `task-34-after-manifest.json` | `db55bc384a04bd48fbfd5c6d783806a120d3b72cb757367e3c3c179496f0a041` |
| `task-34-delta.patch` | `59673278181eef9eb899164f47385e339fe346557eed7a399baa43bd10f7977e` |
| `task-34-scope-proof.json` | `1fdc92fc467ec8613199cb71ea41f4ee96cd68ff0b497d59f8e7482b6bceee07` |

## 有效 RED 与修复后的证据

协议新增 10 个参数用例的首次运行是有效 RED：**7 failed、3 passed，exit1**。DeepSeek chat 普通/流式两个投影用例中，真实 SDK 已发送历史 reasoning，而原 `GraphResources.project_input` 得到的四个 reasoning 全为空。官方摘要 fallback 的五个参数用例均为 false：真实 SDK 返回的 `model_provider` 与保护模型默认 `protectedchatmodel` 不匹配。compatible chat、DeepSeek Responses、Anthropic 的三个投影反向边界本来即通过。

累计 reasoning 的首次运行也是有效 RED：**1 failed，exit1**。每轮使用 4 个合法 AI/Tool 组，各带 48000 个合成 ASCII reasoning，保留必要 Skill 与目标 pin。原生产投影估算 **22441**，实际 SDK body 估算 **86423**；框架没有提前摘要，原最终守卫拒绝 `agent_context_budget_exhausted`。窗口65536、输出8192、工具4096、安全2048均沿原值，输入限额51200。该合成差额仅重现口径缺口，不解释旧 long 的全部960差额。

最小三处生产修复后：

- 新增协议组 **10 passed**，覆盖缺失键、空字符串、多条历史、顺序、原消息不可变，以及其他 provider/协议不新增该字段。实际 SDK 本地 HTTP 请求与真实生产投影进行对照。
- 真实 SDK 返回的 usage/model_provider 交给安装版官方 `SummarizationMiddleware._should_summarize`，合成 counter=0、total_tokens=10、trigger=9 时可触发 fallback；错 provider 仍不触发。super 的 stop/model/max-token LS 字段保留。
- 两轮摘要回归修正夹具后 **1 passed**。每轮经过真实 `SkillSummarizationMiddleware`、`GraphResources`、受保护 SDK 与现有 `RuntimeTransport`；两轮分别触发 helper，主请求及 helper 仍经过相同原准入守卫。摘要 helper 保留 Task33 的 `thinking.disabled`，主请求保持既有默认，不新增 thinking 字段。
- 压缩后使用真实公开 `add_messages` 归约，再经 `MySQLCheckpointSaver._encode/_decode` 的实际 typed codec 恢复；下一轮新累计 reasoning 可再次提前摘要。必要 pin 与其 reasoning 保留，两轮完整输入和投影输入不可变断言均保留。

## 中间失败与纠正

`task-34-green-summary`、`task-34-diagnose-summary-metadata`、`task-34-diagnose-summary-fields` 均为 **exit1**，原日志保留。最初的“metadata 变化”判断不准确；精确字段诊断显示 metadata 完全相同，只有第二轮旧摘要 Human 的 `id` 从 null 变为 UUID。安装版官方 `SummarizationMiddleware._ensure_message_ids` 会给缺失 ID 的消息补 ID。手工 typed 恢复夹具遗漏真实图的 `add_messages` 归约，因此在 encode 前接入真实公开 reducer，使夹具与图状态一致；没有修改产品 middleware，也没有放宽不可变断言。父已接受该夹具修正。

首次测试 Ruff check 发现新增循环内 handler 未绑定 `retained`，为 **B023、exit1**。已用关键字默认参数显式绑定 `retained=retained`，测试 Ruff check/format 复查均 exit0。该最终修改只涉及新增测试闭包，随后定点重验受影响用例为 **1 passed**。

## 回归与门禁

模型协议完整文件：**55 passed，39.78s**。上下文完整组（summary_budget 28 + context_capacity 4）：**32 passed，13.29s**。最后 B023 绑定修正后，新增摘要用例定点复验：**1 passed，10.91s**。32 项组在该纯测试绑定修改前通过，最后 1 项验证了最终受影响测试字节；这些重复批次不累加为唯一测试数。上下文相关运行仅有既有 Starlette/anyio 弃用警告。

源码 Ruff check、源码 format --check、测试 Ruff check（r2）、测试 format --check（r2）、changed dry-run、docs、quality、diff 均 exit0。docs 检查为35份维护文档、121张表、48个路由模块；quality 为1702源文件、0处已知结构问题、118个规模信号待复审。

以下22份原命令记录均保存完整 cwd、argv、开始/闭合时间、退出码、dotenv/live/database 控制和日志路径，`process_closed=true`。所有后端 Python 测试和 Ruff 命令 cwd 为 `backend/`；Node/Git 门禁 cwd 为工作区根目录。

| 阶段 | 退出码与结果 | 原命令 | 原日志 |
| --- | --- | --- | --- |
| red-protocols | 1；7 failed、3 passed | [记录](task-34-red-protocols.command.json) | [日志](task-34-red-protocols.log) |
| red-summary | 1；有效 guard RED | [记录](task-34-red-summary.command.json) | [日志](task-34-red-summary.log) |
| green-protocols | 0；10 passed | [记录](task-34-green-protocols.command.json) | [日志](task-34-green-protocols.log) |
| green-summary | 1；夹具缺失消息 ID | [记录](task-34-green-summary.command.json) | [日志](task-34-green-summary.log) |
| diagnose-summary-metadata | 1；诊断保留 | [记录](task-34-diagnose-summary-metadata.command.json) | [日志](task-34-diagnose-summary-metadata.log) |
| diagnose-summary-fields | 1；仅 ID 变化 | [记录](task-34-diagnose-summary-fields.command.json) | [日志](task-34-diagnose-summary-fields.log) |
| green-summary-r2 | 0；1 passed | [记录](task-34-green-summary-r2.command.json) | [日志](task-34-green-summary-r2.log) |
| import-format | 0；导入排序 | [记录](task-34-import-format.command.json) | [日志](task-34-import-format.log) |
| ruff-format | 0 | [记录](task-34-ruff-format.command.json) | [日志](task-34-ruff-format.log) |
| changed-dry-run | 0 | [记录](task-34-changed-dry-run.command.json) | [日志](task-34-changed-dry-run.log) |
| green-model-regression | 0；55 passed | [记录](task-34-green-model-regression.command.json) | [日志](task-34-green-model-regression.log) |
| green-context-regression | 0；32 passed | [记录](task-34-green-context-regression.command.json) | [日志](task-34-green-context-regression.log) |
| ruff-source-check | 0 | [记录](task-34-ruff-source-check.command.json) | [日志](task-34-ruff-source-check.log) |
| ruff-source-format-check | 0 | [记录](task-34-ruff-source-format-check.command.json) | [日志](task-34-ruff-source-format-check.log) |
| ruff-tests-check | 1；B023，已修复 | [记录](task-34-ruff-tests-check.command.json) | [日志](task-34-ruff-tests-check.log) |
| ruff-tests-format-check | 0 | [记录](task-34-ruff-tests-format-check.command.json) | [日志](task-34-ruff-tests-format-check.log) |
| check-docs | 0 | [记录](task-34-check-docs.command.json) | [日志](task-34-check-docs.log) |
| check-quality | 0 | [记录](task-34-check-quality.command.json) | [日志](task-34-check-quality.log) |
| diff-check | 0 | [记录](task-34-diff-check.command.json) | [日志](task-34-diff-check.log) |
| green-summary-final | 0；1 passed | [记录](task-34-green-summary-final.command.json) | [日志](task-34-green-summary-final.log) |
| ruff-tests-check-r2 | 0 | [记录](task-34-ruff-tests-check-r2.command.json) | [日志](task-34-ruff-tests-check-r2.log) |
| ruff-tests-format-check-r2 | 0 | [记录](task-34-ruff-tests-format-check-r2.command.json) | [日志](task-34-ruff-tests-format-check-r2.log) |

## 保持不变与验证限制

[scope proof](task-34-scope-proof.json) 逐字节核对了 middleware、budget、summarization、model_ledger、自然 live、Task33 Worker/acceptance runner、pyproject、uv.lock、Task33 r2 manifest/delta 的原哈希。自然 long/live 源 SHA256 仍为 `bd6ade134fbda1377983ed3b5e32734ea1d7d30e3fbb1d2f2d4e7da0385e5ebe`。旧 Task33/v33 产物不覆盖，旧 v33 失败结论不追认。

本次运行器禁用应用 dotenv、缺省 FASTMCP env 文件、外部 tracing 和 live opt-in，所有记录均 `mysql=false`。仅使用本地 HTTP fixture 或现有受控 transport，没有真实模型/媒体请求，没有数据库或 Docker 操作。typed codec 覆盖不等于真实 MySQL SQL 持久化或跨 Worker 恢复验收。没有重跑 Task33 无关的80项模型/9项 Worker 套件，也没有启动自然 long 或新版 wire probe。

修复证明平台估算应覆盖实际发出的 DeepSeek 历史 reasoning，且官方摘要可识别真实 SDK 身份；不推断供应商是否把 reasoning 计作输入 tokens，不宣称两处缺口解释旧 long 的全部差额或其他 Skill/JSON 失败。真实供应商行为与完整长程验收仍由父在独立审查后另行决定并记录新的源身份。
