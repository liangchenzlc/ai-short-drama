# Task35：已确认非法工具参数的框架有界恢复

2026-11-01。实施与验证已闭合，源码、测试停止写入，交父任务 fresh 限定审查。仅修改一个生产文件与一个现有测试文件；维护文档由父任务同步。

## 改动及边界

- `backend/src/short_drama/agent/runtime/agent.py`：保留 `invalid_tool_selection` 原判断与 executor 的既有分类；新增 `retryable_model_output`，提供给原有官方 `ModelRetryMiddleware.retry_on`。
- 新增分支仅接受 `AgentGatewayError`，且必须同时满足 `code=invalid_agent_tool_calls`、`accepted_unknown=false`、`requests>0`。`max_retries=2`、`initial_delay=0`、`on_failure=error` 原值保留。
- `backend/tests/unit/standard/agent/test_assistant_model_protocols.py`：从实际 `assistant_middleware` 取官方 retry；内存传输只替代受保护模型的外部发送，真实 protected SDK、SSE 解析、gateway 校验和 `create_agent` 均执行。未复制重试循环，也未修补坏 JSON。
- 本次只用 Task35 brief、已闭合 wire diagnosis 与源码定位边界；未读取供应商 raw 或工具参数正文，测试的非法 JSON 为新建的固定合成数据。
- Task34 三个生产文件逐字节 SHA 与 `task-34-after-manifest.json` 全相符：`gateway/deepseek.py`、`gateway/langchain.py`、`resources/graph.py`。未调整 Gateway、提示、预算、依赖锁、工具/存储结算、live 长测。

## RED → GREEN 实证

1. 生产修改前保存两个文件完整原始字节及 SHA，位于 `task-35-before/` 与 `task-35-before.json`。
2. 首次 RED 为 3 failed / 8 passed / 55 deselected：两个目标故障及一个取消断言不符合 graph 的官方包装。只修正取消预期为 `NodeCancelledError`，原日志保留 `task-35-red-initial.*`。
3. 有效 RED 为 **2 failed / 9 passed / 55 deselected，exit 1**：首次完整非法参数原错终止；连续非法参数也仅调用一次，无法达到原官方配置允许的三次总尝试。对应 `task-35-red.log` 与 `task-35-red-exit.json`。
4. 最小生产改动后，新增定点 **11 passed / 55 deselected，exit 0**。最终格式化并保存安全回执后，新增定点加原 `test_agent_context_capacity.py` 四项回归为 **15 passed / 55 deselected，exit 0**，见 `task-35-green-final.*`。

实际行为由真实 graph 与官方 retry 证明：

| 场景 | 观察结果 |
| --- | --- |
| 第一次完整非法参数，第二次合法调用，随后自然文本结束 | 总计三次模型请求；合法工具仅执行一次；坏参数没有进入工具或后续输入；结束为 Complete |
| 连续三个完整非法参数，队列后仍有合法响应 | 仅三次请求后保留 `invalid_agent_tool_calls` 原错退出；合法响应未消费，工具零执行 |
| 保存的首次坏响应再走真实 raw replay | 同一非法参数仍报错，`requests=0`；graph 的模型尝试计数为 1，发送/admission/raw/usage/error 回调数量均不增加 |
| 原工具名称选择 ValueError | 官方 retry 调用第二次后正常结束，原行为保持 |
| invalid 参数但 accepted_unknown=true 或 requests=0 | 一次后原错退出 |
| context budget、authentication、truncated、stream cancelled、无关 ValueError | 一次后原错退出 |
| asyncio.CancelledError | 一次后由 graph 以 NodeCancelledError 传播，cause 为原取消对象 |

两个 protected SDK 场景各自实际生成三个不同 `model_call_id`；admission、raw、usage 一一对应，错误回执分别对应首一条或前三条身份。合成供应商每次报告 input=7 / output=3 / external_requests=1，失败输出的用量回调仍保留，错误回执为 `accepted_unknown=false`、`not_accepted=false`。回执由正式 pytest 属性写入 `task-35-receipts.xml`，另提取为 `task-35-safe-receipts.json`；仅含合成场景安全身份、用量与错误事实，不含 raw 或工具参数。

## 已执行门禁

| 检查 | 结果 |
| --- | --- |
| 新定点及 context_capacity 回归 | 15 passed，55 个原协议测试 deselected，exit 0 |
| `python -m ruff check src` | exit 0 |
| `python -m ruff check tests` | exit 0 |
| `python -m ruff format --check src` | 1155 文件已格式化，exit 0 |
| `python -m ruff format --check tests` | 408 文件已格式化，exit 0 |
| `node scripts/test.mjs --changed --dry-run` | exit 0，工作区现有改动计划 269 个测试；只预览，不执行该大范围 |
| `node scripts/check-docs.mjs` | 35 份维护文档、121 表、48 路由模块，exit 0 |
| `node scripts/check-quality.mjs` | 1702 源文件，0 已知结构问题，exit 0；现存规模提示保留 |
| `git diff --check` | exit 0；工作区既有 LF/CRLF 提示保留 |

Ruff 首轮发现本次新增测试行宽/导入格式，已只格式化该测试文件，再实际执行四项全通过；首轮日志保留为 `task-35-ruff-*-initial.log`。

测试从 `backend/` 执行，先设置 `PYTHONPATH=src;.`、`PYTHON_DOTENV_DISABLED=1`、`PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`、`LANGSMITH_TRACING=false`、`LANGCHAIN_TRACING=false`、`LANGCHAIN_TRACING_V2=false`、`OTEL_SDK_DISABLED=true`，并在导入 pytest 前设 `Settings.model_config['env_file']=None`。最终核心命令为：

```python
pytest.main([
    'tests/unit/standard/agent/test_assistant_model_protocols.py',
    'tests/unit/standard/agent/test_agent_context_capacity.py',
    '-k', 'official_retry or selector_retry_predicate or capacity_declaration',
    '-q', '--tb=short', '-p', 'no:cacheprovider',
    '--junitxml', '../.runtime/sdd/2026-10-29-创作助手运行时与工具扩展重构实施/task-35-receipts.xml',
    '-o', 'junit_family=legacy',
])
```

上述验证命令的开始、结束、退出状态保存在对应 `task-35-*-exit.json`；原始输出保存在同名前缀日志。没有仍运行的验证命令。

## 冻结与未验证范围

- 最小 before、after 保留两个文件原始字节；`task-35-after-manifest.json` 记录前后 SHA 与大小；`task-35-delta.patch` 只对统一差异作 LF 归一化，不改快照字节。
- 最终 `agent.py` SHA：`889d49b519cf777158b6f5ab45df9abd7d92729c8d1188bd060f41b3183c3530`。
- 最终 `test_assistant_model_protocols.py` SHA：`115c9a5f5c1f361417d206cb065b04f72872d92ac850fd77d8b6e472c8bd815a`。
- `task-35-freeze.json` 汇总两个文件、原三生产文件保持事实及实际门禁；未建立新的全仓快照流程。
- 未连接任何网络/TCP、真实模型、媒体、MySQL、Docker；没有读取凭据或 `.env`，没有提交或操作 index/HEAD，没有派子代理。
- 55 个已有协议测试未重跑：其 localhost fixture 会扩大网络范围，父任务明确同意沿用 Task34 已通过结果，不把它们计入本次通过数。context_capacity 四项已实际回归。
- 本次为真实框架和 SDK 的合成响应验证，**不是供应商验收或数据库持久化结算验收**。旧 wire 结果仍为 1 failed / 1 passed；完整 45 项和三次长任务未全部通过的事实保留。本地通过不追认旧失败或 unknown。
- 父任务负责维护文档、fresh 审查和其授权的一次新版实际核验；应用库迁移、用户服务切换、完整 Celery 部署仍不在本次范围。
