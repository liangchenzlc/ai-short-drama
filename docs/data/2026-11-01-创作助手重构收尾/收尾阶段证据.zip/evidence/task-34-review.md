# Task34 独立 Spec + Quality 审查

日期：2026-11-01。唯一规格为 [task-34-brief.md](task-34-brief.md)。结论：**Approved**。Spec compliance 通过；Quality **C=0 / I=0 / M=0**（🔴 阻塞／🟡 应修／🟢 可选）。未发现本次限定修复中需要修改的问题。

## 范围与方法

已先读 PRINCIPLES、根／backend AGENTS、brief、prepare、v33-before34-source-proof 与 before manifest，按 `code-review-skill` 全文及 Python、通用质量、错误处理、N+1、并发指南，完成范围确认、设计层、逐行和结论四阶段。对照七路径冻结 before、当前源码和 after；阅读必要的生产调用链及本机已装官方 SDK／摘要源码。生产差异仅 gateway/deepseek.py、gateway/langchain.py、resources/graph.py，两正式测试和两维护文档；middleware 未改。

审查者未修改 tracked 文件，未运行 pytest 或重复大套件，未访问网络、模型、数据库、Docker、应用 dotenv、凭据或供应商 raw 产物。独立执行了哈希核验与纯标准库全上下文 delta 重建；唯一写入为本报告及 [审查证据](task-34-review-evidence.json)。

## Spec compliance

| 规格 | 审查结果与证据 |
| --- | --- |
| 实际 SDK 与计量包含同一历史 reasoning | `gateway/deepseek.py:10` 的 `with_reasoning_content` 复制序列化消息 dict，按 strict zip 对已存在键回填；SDK 和 `resources/graph.py:126` 共用该函数。保留空字符串、缺失键、多条顺序，未改原消息。新增协议测试比较本地 HTTP fixture 捕获的实际 SDK body 与真实 GraphResources 投影，并保留完整输入不可变断言。 |
| provider／协议与媒体边界 | 投影分支只在 DeepSeek + openai_chat 生效，仍先 references_only 水合，再 request_template；原媒体引用替换流程保留。compatible chat、DeepSeek Responses、Anthropic 的反向用例不引入 reasoning 字段；既有媒体模板／回执用例包含在完整模型组。此次没有新增组合媒体供应商验收。 |
| 框架身份与官方 fallback | `gateway/langchain.py:174` 先调用 super，只补 ls_provider；映射与该文件实际 SDK 选择及安装版 SDK 身份一致。DeepSeek chat→deepseek、Claude→anthropic，其余 ChatOpenAI 路径→openai，未把产品 compatible 当 SDK 身份。测试使用 SDK 真实解析的 usage/model_provider 调官方 `_should_summarize`，包含错 provider 反向及 super stop/model/max-token 字段断言；没有复制判断常量充当证明。 |
| 有效 RED | 协议首次运行 7 failed / 3 passed；失败分别为真实投影遗漏和官方 fallback 不触发。摘要首次运行沿实际 SDK 准入链失败为 `agent_context_budget_exhausted`，原投影22441、实际body86423，属于行为失败，非 import 失败。原日志未覆盖。 |
| 两轮默认摘要与恢复 | `test_agent_summary_budget.py:253` 使用完整 AI/Tool 组、活动 Skill 与目标 pin、累计合成 reasoning，直接调用真实 middleware、GraphResources、受保护 SDK、原 provider_budget 和 typed codec；两轮均要求发生摘要并通过同一守卫。窗口65536／输出8192／工具4096／安全2048、输入限额51200不变，主 thinking 与摘要 disabled 均有断言。 |
| 夹具纠正是否放松断言 | 保留中间失败和精确字段诊断：变化仅为旧 summary 的 id 从 null 到 UUID，metadata 相同；安装版官方 `_ensure_message_ids` 解释该行为。最终夹具在 encode 前使用公开 add_messages 归约，完整 messages_to_dict 不可变断言仍在，未修改产品 middleware。 |
| 约束与维护说明 | 限定差异没有新增重试、JSON／Skill 修复、预算放宽、提示或依赖变更；两维护文档准确说明平台估算、SDK 身份与供应商 token 语义的边界。独立复核 scope-proof 的11项保护哈希一致，含 middleware、budget、summarization、model_ledger、锁文件、Task33产物及 live 源。 |

## Quality 与验证证据

共享函数复用原薄桥行为，未新增序列化器或摘要算法；新增依赖方向未形成循环。补丁没有新增 I/O、任务、锁、取消或资源生命周期，未发现新增并发、错误处理、性能或安全问题。新增测试使用生产函数与官方实现，最终闭包显式绑定 retained；无 C／I／M 发现。

已逐条核实际命令 JSON、原日志及 [正式交付报告](task-34-report.md)，22份先前记录均 process_closed=true，退出码与保留的失败／最终成功一致，freeze 自身 closed/exit0。以下为实现者实际运行证据，审查者没有重跑：

- [完整模型回归](task-34-green-model-regression.log)：55 passed，覆盖正式模型、流式、媒体模板、thinking、usage、typed 恢复及 raw replay 相关既有用例。
- [完整上下文组](task-34-green-context-regression.log)：32 passed；最后 B023 测试闭包修正后的 [摘要定点复验](task-34-green-summary-final.log)：1 passed。该1项与前述组重叠，不累加唯一测试数。
- 源码 Ruff check／format --check、测试 Ruff check-r2／format --check-r2、changed dry-run、docs、quality、diff 均 closed/exit0。首次 Ruff B023 与中间摘要夹具失败保留并明确解释；最终受影响用例已复验。日志只见既有 Starlette/anyio 弃用警告。

## 冻结身份

七路径 before 与 before manifest、after 快照与 after manifest、当前字节均独立核对一致；188693字节完整上下文 delta 已由 before/after 独立重建并逐字节相等。

| 路径 | 审查时 after／当前 SHA256 |
| --- | --- |
| backend/src/short_drama/agent/gateway/deepseek.py | `135838ff361aa9bc8ea5cbcfbf6bc8f64878f0f27956f161e3462b7282066ca5` |
| backend/src/short_drama/agent/gateway/langchain.py | `d103b5df6b63f72c940315a8e0d156a5fd7b7fc858f80c9387a942a31f47caac` |
| backend/src/short_drama/agent/resources/graph.py | `be22f03c13080c14c90228c45ddcc82e904339d075c1ed6747a46df598e13958` |
| backend/tests/unit/standard/agent/test_assistant_model_protocols.py | `7768190f75b2706a3a2a36fad81c2d7d9fe03d01e219c9e4a721b90a2e559d93` |
| backend/tests/unit/standard/agent/test_agent_summary_budget.py | `b019444c7831f1a5dbbb0fa4da0b48452332a409b4e7f5c9f7f56b667aa2fffd` |
| docs/instruction/Agent模式部署与排障.md | `29fd79a134acc5a52d17bf64c6204c8654febcae72c96514e786411b77c896dd` |
| docs/instruction/AI创作助手Harness运行机制.md | `95e5b3143d9ab892e944d5155befe8c6a7c0720b05440272f9cd7ac77d45e57d` |

- after-manifest：`db55bc384a04bd48fbfd5c6d783806a120d3b72cb757367e3c3c179496f0a041`
- delta：`59673278181eef9eb899164f47385e339fe346557eed7a399baa43bd10f7977e`
- 正式 report：`53adbe812b52d47fee16ce9e3a62e357f3fd5ae1d7c68dd25dd6888adc49d53a`
- 自然 live 源保持：`bd6ade134fbda1377983ed3b5e32734ea1d7d30e3fbb1d2f2d4e7da0385e5ebe`

## 结论的适用范围

**Approved：Task34 限定修复可交父进入下一步决策。** 本次证据证明本地 SDK 序列化／计量接线、官方用量兜底与受控两轮摘要和 typed codec 行为；不证明真实供应商行为、自然长程验收、真实 MySQL 持久化或跨 Worker 恢复。本次没有重跑 Task33 Worker 套件；不追认旧 v33 失败，不将合成差额解释成旧 long 全部差额，不推断供应商是否将 reasoning 计为输入 tokens。新版真实 probe／验收仍由父另行决定与记录。
