# 最终收尾用量：after35

唯一最终短核验 deepseek-close-v35a 已正式闭合，exit 0；两项 crash 参数均通过。新增 2 Run / 20 receipt / 20 model_call_id，与 v34 以前的三类身份均无重复。

| 范围 | Run | receipt | input | output | cached | reserved output |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| v34 累计 | 388 | 5,995 | 43,792,761 | 1,790,811 | 13,281,055 | 114,688 |
| v35 最终短核验增量 | 2 | 20 | 140,853 | 3,935 | 121,600 | 0 |
| 最终合并 | 390 | 6,015 | 43,933,614 | 1,794,746 | 13,402,655 | 114,688 |

input 缺失仍为 2 Run；原 14 个未决身份及 114,688 Run 预留原样保留，新批无新增未决或预留。旧摘要 sanity/preflight、probe、provider 诊断及其 unknown、GET discovery 均独立保留，未加入 Run 用量。实际供应商账单 unknown。

这是已闭合历史用量收尾与两项短核验结果，不构成跨版本完整 45 项通过或 Task12 验收通过。历史失败、未执行及未知覆盖缺口继续保留，没有重新运行测试或新增外部调用。

全部来源 SHA/bytes、新增安全身份及数字用量见 [最终 JSON](./closing-usage-after35.json)；之前的历史文件未覆盖。
