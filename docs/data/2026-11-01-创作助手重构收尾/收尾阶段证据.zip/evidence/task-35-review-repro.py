"""One offline review probe for retry/summarization compaction ownership."""

import asyncio
import hashlib
import json
import os
import socket
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
os.environ["PYTHON_DOTENV_DISABLED"] = "1"
os.environ["LANGCHAIN_TRACING_V2"] = "false"
os.environ["LANGSMITH_TRACING"] = "false"
os.environ["LANGSMITH_OTEL_ENABLED"] = "false"


def no_network(*args, **kwargs):
    raise AssertionError("Network is forbidden in this offline review probe")


from short_drama.core.config import Settings

Settings.model_config["env_file"] = None

from langchain.agents.factory import _chain_async_model_call_handlers
from langchain.agents.middleware import ModelRetryMiddleware
from langchain.agents.middleware.types import ModelRequest, ModelResponse
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    RemoveMessage,
    message_to_dict,
    messages_from_dict,
)
from langgraph.graph.message import REMOVE_ALL_MESSAGES, add_messages
from langgraph.runtime import Runtime

from short_drama.agent.gateway.contracts import AgentGatewayError
from short_drama.agent.runtime.agent import assistant_middleware, bound_model_middleware
from short_drama.agent.runtime.context import model_compaction
from short_drama.agent.runtime.middleware import SkillSummarizationMiddleware
from tests.support.assistant_model import ScriptedModel


async def probe():
    # Install after asyncio's Windows self-pipe initialization.
    socket.socket.connect = no_network
    socket.create_connection = no_network
    summary_model = ScriptedModel(
        replies=[AIMessage(content="summary-attempt-one"), AIMessage(content="summary-attempt-two")]
    )
    retry = next(
        item
        for item in assistant_middleware(
            model=summary_model,
            tools=[],
            snapshot={
                "assistant_settings": {"tool_selector_prompt": "unused", "model_call_limit": 9}
            },
        )
        if isinstance(item, ModelRetryMiddleware)
    )
    summary = SkillSummarizationMiddleware(
        model=summary_model, trigger=("messages", 2), keep=("messages", 1)
    )
    middleware = bound_model_middleware([summary, retry])
    chain = _chain_async_model_call_handlers([item.awrap_model_call for item in middleware])
    messages = [
        HumanMessage(content="Old request", id="history-human"),
        AIMessage(content="Old answer", id="history-ai"),
        HumanMessage(content="Current request", id="current-human"),
    ]
    request = ModelRequest(
        model=summary_model, messages=messages, state={"messages": messages}, runtime=Runtime()
    )
    attempts = []

    async def handler(current):
        attempts.append(list(current.messages))
        if len(attempts) == 1:
            raise AgentGatewayError("invalid_agent_tool_calls", requests=1)
        return ModelResponse(result=[AIMessage(content="Complete", id="final-answer")])

    token = model_compaction.set([])
    try:
        response = await chain(request, handler)
        pending = model_compaction.get()
        # Same serializer/replay reducer used by model_result/model_input, without a DB.
        graph_compaction = [message_to_dict(item) for item in pending]
        graph_message = message_to_dict(response.model_response.result[-1])
        live = add_messages(messages, response.commands[-1].update["messages"])
        replay = add_messages(
            messages,
            [
                RemoveMessage(id=REMOVE_ALL_MESSAGES),
                *messages_from_dict(graph_compaction),
                *messages_from_dict([graph_message]),
            ],
        )
        summaries = lambda values: [
            item for item in values if item.additional_kwargs.get("lc_source") == "summarization"
        ]
        evidence = {
            "network_forbidden": True,
            "dotenv_disabled": True,
            "tracking_disabled": True,
            "official_retry_from_production": type(retry).__name__,
            "production_order": [type(item).__name__ for item in middleware],
            "main_handler_attempts": len(attempts),
            "real_summary_helper_calls": len(summary_model.requests),
            "official_success_commands": len(response.commands),
            "pending_messages": len(pending),
            "live_summary_count": len(summaries(live)),
            "replay_summary_count": len(summaries(replay)),
            "failed_attempt_summary_in_replay": any(
                item.content.endswith("summary-attempt-one") for item in summaries(replay)
            ),
            "failed_attempt_summary_in_live": any(
                item.content.endswith("summary-attempt-one") for item in summaries(live)
            ),
        }
        assert evidence["main_handler_attempts"] == evidence["real_summary_helper_calls"] == 2
        assert evidence["official_success_commands"] == 1
        assert evidence["live_summary_count"] == 1 and evidence["replay_summary_count"] == 2
        assert evidence["failed_attempt_summary_in_replay"]
        assert not evidence["failed_attempt_summary_in_live"]
        return evidence
    finally:
        model_compaction.reset(token)


evidence = asyncio.run(probe())
root = Path.cwd().parent
evidence["reviewed_sha256"] = {
    str(path): hashlib.sha256((root / path).read_bytes()).hexdigest()
    for path in (
        Path("backend/src/short_drama/agent/runtime/agent.py"),
        Path("backend/tests/unit/standard/agent/test_assistant_model_protocols.py"),
    )
}
output = json.dumps(evidence, ensure_ascii=False, indent=2) + "\n"
Path(__file__).with_suffix(".json").write_text(output, encoding="utf-8")
sys.stdout.write(output)
